tinymce.addI18n('fr_FR', {
    "Insert/Edit Bootstrap Button": "Insérer/Editer un Bouton",
    "Insert/Edit Bootstrap Icon": "Insérer/Editer un Icône",
    "Insert/Edit Bootstrap Image": "Insérer/Editer une Image",
    "Insert/Edit Bootstrap Table": "Insérer/Editer un Tableau",
    "Insert Bootstrap Template": "Insérer un Modèle",
    "Insert/Edit Bootstrap Breadcrumb": "Insérer/Editer un Fil d'Ariane",
    "Insert/Edit Bootstrap Pagination": "Insérer/Editer une barre de Pagination",
    "Insert/Edit Bootstrap Pager": "Insérer/Editer un Pager",
    "Insert/Edit Bootstrap Label": "Insérer/Editer un Label",
    "Insert/Edit Bootstrap Badge": "Insérer/Editer un Badge",
    "Insert/Edit Bootstrap Alert": "Insérer/Editer une Alerte",
    "Insert/Edit Bootstrap Panel": "Insérer/Editer un Panel",
    "Insert/Edit Snippet": "Insérer/Editer un Snippet"
});