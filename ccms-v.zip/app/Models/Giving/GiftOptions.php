<?php

namespace App\Models\Giving;

use Illuminate\Database\Eloquent\Model;

class GiftOptions extends Model
{
    protected $fillable=['name','desc','active','amount'];

}
