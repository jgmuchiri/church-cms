<?php

namespace App\Models\Billing;

use Illuminate\Database\Eloquent\Model;

class MembershipPlans extends Model
{
    //
}
