<?php

namespace App\Models\Blog;

use Illuminate\Database\Eloquent\Model;

class BlogComments extends Model
{
    //
}
