@extends('emails.template')
@section('content')

    {!! $msg !!}
@endsection

