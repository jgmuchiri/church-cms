@extends('errors.template')

@section('title')
    Access Denied
@endsection

@section('content')
    <h3>Sorry, it looks like you ventured too far from safe-land. Retrace your steps back home</h3>
@endsection