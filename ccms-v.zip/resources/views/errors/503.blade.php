@yield('errors.template')
@section('title')
    Be right back.
@endsection
@section('content')
    Be right back.
@endsection