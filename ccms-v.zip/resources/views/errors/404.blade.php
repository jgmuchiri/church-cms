@extends('errors.template')
@section('title')
   404 Error!
@endsection
@section('content')
    <h2>Page not found</h2>
    Go back and try a different search term
@endsection