@extends('layouts.template')

@section('title')
    Access denied
@endsection
@section('title-icon')exclamation
@endsection

@section('content')
    <h3>You do not have permission to access that resource</h3>
    <h3>Sorry :(</h3>
@endsection
